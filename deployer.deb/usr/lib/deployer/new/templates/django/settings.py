
STATIC_ROOT = BASE_DIR / "staticfiles"
